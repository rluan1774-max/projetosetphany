# STEPHANY — Estúdio de Manicure

Site institucional e landing page de alta conversão para o estúdio de manicure **STEPHANY** em Araguari - MG.

## 🚀 Como hospedar na NETLIFY (em menos de 1 minuto)

### Opção 1: Arrastar e Soltar (Sem código / Mais fácil)
1. Extraia o arquivo `dist.zip` (ou use a pasta `dist` gerada com `npm run build`).
2. Acesse: **https://app.netlify.com/drop**
3. Arraste a pasta `dist` para dentro da tela.
4. Pronto! Seu site estará online com HTTPS gratuito e domínio próprio em segundos.

### Opção 2: Pelo GitHub / Repositório Netlify
1. Conecte seu repositório no Netlify.
2. Defina as configurações de build:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
3. Clique em **Deploy site**.

---

## 💜 Como usar no LOVABLE
1. No Lovable, clique em **Create new project** ou **Import Project**.
2. Selecione o arquivo `stephany-manicure-site.zip` (código-fonte completo).
3. O Lovable reconhecerá automaticamente a estrutura React + Vite + Tailwind CSS.

---

## 💻 Como rodar localmente no seu computador

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```

3. Para gerar a versão de produção:
   ```bash
   npm run build
   ```

---

## 📞 Informações do Estúdio
- **Nome**: STEPHANY
- **Endereço**: Rua Amazonas, N 115. Bairro Brasília - Araguari, MG
- **WhatsApp**: (34) 98830-8413
