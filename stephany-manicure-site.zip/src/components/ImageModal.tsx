import React, { useEffect } from 'react';
import { X, MessageCircle, Sparkles } from 'lucide-react';
import { GalleryItem } from '../types';
import { STUDIO_INFO } from '../data/studioData';

interface ImageModalProps {
  item: GalleryItem | null;
  onClose: () => void;
}

export const ImageModal: React.FC<ImageModalProps> = ({ item, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (item) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [item, onClose]);

  if (!item) return null;

  const message = encodeURIComponent(
    `Olá, Stephany! Adorei a referência de unhas "${item.title}" (${item.category}) que vi no seu site. Gostaria de saber a disponibilidade para fazer algo nesse estilo!`
  );
  const whatsappUrl = `https://wa.me/${STUDIO_INFO.phoneClean}?text=${message}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#1C1226]/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative max-w-3xl w-full bg-[#FAF7F5] rounded-[32px] overflow-hidden shadow-2xl border border-white/20 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white transition-colors"
          aria-label="Fechar visualização"
        >
          <X className="w-5 h-5" />
        </button>

        {/* High res image */}
        <div className="relative w-full max-h-[65vh] overflow-hidden bg-black flex items-center justify-center">
          <img
            src={item.image}
            alt={item.title}
            className="w-full h-full max-h-[65vh] object-contain sm:object-cover"
          />
        </div>

        {/* Caption & Actions */}
        <div className="p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white">
          <div>
            <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#6B21A8]">
              {item.category}
            </span>
            <h3 className="font-editorial text-2xl font-medium text-[#1C1226] mt-0.5">
              {item.title}
            </h3>
            <p className="text-xs text-[#6B6275] font-light mt-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#F472B6]" />
              <span>Realizado no Estúdio Stephany • Araguari MG</span>
            </p>
          </div>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-[#6B21A8] hover:bg-[#581c87] text-white text-xs uppercase tracking-wider font-semibold shadow-md hover:shadow-lg transition-all shrink-0"
          >
            <MessageCircle className="w-4 h-4 text-[#F472B6]" />
            <span>Quero esse estilo</span>
          </a>
        </div>
      </div>
    </div>
  );
};
