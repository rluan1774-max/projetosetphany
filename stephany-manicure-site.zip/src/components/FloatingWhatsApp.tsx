import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { STUDIO_INFO } from '../data/studioData';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const defaultMessage = encodeURIComponent('Olá, Stephany! Vi seu site e gostaria de saber os horários disponíveis.');
  const whatsappUrl = `https://wa.me/${STUDIO_INFO.phoneClean}?text=${defaultMessage}`;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3">
      {/* Tooltip prompt */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 bg-white text-[#1C1226] text-xs py-2 px-3.5 rounded-full shadow-lg border border-[#6B21A8]/15 animate-in fade-in slide-in-from-right-3 duration-300">
          <span className="w-2 h-2 rounded-full bg-[#F472B6] animate-pulse" />
          <span className="font-medium">Agende seu horário</span>
          <button
            onClick={() => setShowTooltip(false)}
            className="text-[#6B6275] hover:text-[#1C1226] ml-1"
            aria-label="Fechar aviso"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Falar com Stephany no WhatsApp"
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-[#6B21A8] hover:bg-[#581c87] text-white shadow-xl hover:shadow-2xl hover:shadow-[#6B21A8]/40 transition-all duration-300 transform hover:scale-105 active:scale-95"
      >
        <MessageCircle className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />

        {/* Pulse ring */}
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#F472B6] opacity-75"></span>
          <span className="relative inline-flex rounded-full h-4 w-4 bg-[#F472B6] border-2 border-white"></span>
        </span>
      </a>
    </div>
  );
};
