import React from 'react';
import { ArrowUp, Sparkles, Heart } from 'lucide-react';
import { STUDIO_INFO } from '../data/studioData';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#FAF7F5] border-t border-[#6B21A8]/10 pt-16 pb-12 text-[#1C1226]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 pb-12 border-b border-[#6B21A8]/10">
          
          {/* Brand info */}
          <div className="max-w-sm">
            <span className="font-editorial text-3xl font-bold tracking-widest text-[#6B21A8] block">
              {STUDIO_INFO.name}
            </span>
            <span className="text-[10px] tracking-[0.25em] uppercase text-[#6B6275] block mt-1 font-medium">
              Estúdio de Manicure • Araguari - MG
            </span>
            <p className="text-xs text-[#6B6275] font-light mt-4 leading-relaxed">
              {STUDIO_INFO.slogan} Cuidado meticuloso, produtos de alta durabilidade e ambiente acolhedor.
            </p>
          </div>

          {/* Quick links & Contact summary */}
          <div className="flex flex-col sm:flex-row sm:items-start gap-8 sm:gap-14 text-xs">
            <div>
              <p className="uppercase tracking-widest font-semibold text-[#6B21A8] mb-3">
                Localização
              </p>
              <p className="text-[#6B6275] font-light leading-relaxed">
                Rua Amazonas, N 115<br />
                Bairro Brasília — Araguari, MG
              </p>
            </div>

            <div>
              <p className="uppercase tracking-widest font-semibold text-[#6B21A8] mb-3">
                Atendimento
              </p>
              <a
                href={`https://wa.me/${STUDIO_INFO.phoneClean}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#6B6275] hover:text-[#6B21A8] font-light block transition-colors"
              >
                {STUDIO_INFO.phoneDisplay}
              </a>
              <span className="text-[#6B6275]/70 text-[11px] block mt-1">
                Agendamentos com hora marcada
              </span>
            </div>

            <button
              onClick={scrollToTop}
              className="self-start sm:self-center p-3 rounded-full bg-white border border-[#6B21A8]/15 hover:border-[#6B21A8] text-[#6B21A8] transition-all shadow-xs hover:shadow-md"
              aria-label="Voltar ao topo"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>

        </div>

        {/* Export / Download Project ZIP Banner */}
        <div className="py-6 my-6 border-y border-[#6B21A8]/10 flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/60 p-4 rounded-2xl">
          <div className="text-left">
            <p className="text-xs font-semibold text-[#1C1226]">
              📦 Exportar Projeto para Hospedagem
            </p>
            <p className="text-[11px] text-[#6B6275]">
              Pronto para importar no Lovable ou arrastar na Netlify (app.netlify.com/drop).
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <a
              href="/stephany-manicure-site.zip"
              download="stephany-manicure-site.zip"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#6B21A8] hover:bg-[#581c87] text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <span>Baixar ZIP (Código / Lovable)</span>
            </a>
            <a
              href="/stephany-dist-pronto-netlify.zip"
              download="stephany-dist-pronto-netlify.zip"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white border border-[#6B21A8]/20 hover:border-[#6B21A8] text-[#6B21A8] text-xs font-semibold transition-colors"
            >
              <span>Baixar Dist (Netlify Drop)</span>
            </a>
          </div>
        </div>

        {/* Copyright notice */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between text-xs text-[#6B6275] gap-4">
          <p>
            © {new Date().getFullYear()} {STUDIO_INFO.name}. Todos os direitos reservados.
          </p>
          <p className="flex items-center gap-1.5 text-[11px]">
            <span>Beleza, autocuidado e precisão em Araguari</span>
            <Sparkles className="w-3 h-3 text-[#F472B6]" />
          </p>
        </div>
      </div>
    </footer>
  );
};
