import React from 'react';
import { Eye, Sparkles } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/studioData';
import { GalleryItem } from '../types';

interface GallerySectionProps {
  onOpenImage: (item: GalleryItem) => void;
}

export const GallerySection: React.FC<GallerySectionProps> = ({ onOpenImage }) => {
  return (
    <section id="galeria" className="py-24 sm:py-32 relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 sm:mb-20">
          <span className="text-xs uppercase tracking-[0.25em] font-semibold text-[#6B21A8] block mb-3">
            Portfólio & Detalhes
          </span>
          <h2 className="font-editorial text-fluid-section text-[#1C1226] font-normal mb-4">
            A Beleza nos Detalhes
          </h2>
          <p className="text-sm sm:text-base text-[#6B6275] font-light leading-relaxed">
            Cada unha esculpida reflete harmonia, cutículas perfeitas e durabilidade sem igual.
          </p>
        </div>

        {/* Asymmetrical Editorial Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {GALLERY_ITEMS.map((item, index) => {
            // Give subtle layout rhythm
            const isTall = index === 0 || index === 4;
            return (
              <div
                key={item.id}
                onClick={() => onOpenImage(item)}
                className={`group relative overflow-hidden rounded-[28px] cursor-pointer bg-[#F3ECE7] border border-[#6B21A8]/10 shadow-sm hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1 ${
                  isTall ? 'sm:row-span-2' : ''
                }`}
              >
                <div className={`relative w-full ${isTall ? 'h-[460px] sm:h-[580px]' : 'h-[320px] sm:h-[360px]'}`}>
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    loading="lazy"
                  />

                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1C1226]/85 via-[#1C1226]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6" />

                  {/* Caption & Category */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-3 group-hover:translate-y-0 opacity-90 group-hover:opacity-100 transition-all duration-300">
                    <span className="inline-block text-[10px] uppercase tracking-[0.2em] font-semibold text-[#F472B6] mb-1">
                      {item.category}
                    </span>
                    <h3 className="font-editorial text-lg sm:text-xl font-medium leading-snug">
                      {item.title}
                    </h3>
                  </div>

                  {/* Zoom indicator icon */}
                  <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/80 backdrop-blur-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-sm">
                    <Eye className="w-4 h-4 text-[#6B21A8]" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Minimalist reassurance line */}
        <div className="mt-12 text-center">
          <p className="text-xs uppercase tracking-[0.18em] text-[#6B6275] inline-flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#F472B6]" />
            <span>Trabalhos 100% reais realizados no ateliê em Araguari</span>
          </p>
        </div>

      </div>
    </section>
  );
};
