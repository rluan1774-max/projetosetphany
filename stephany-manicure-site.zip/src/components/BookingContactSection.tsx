import React, { useState } from 'react';
import { MessageCircle, MapPin, Phone, Calendar, Clock, Sparkles, CheckSquare, Square } from 'lucide-react';
import { STUDIO_INFO, BOOKING_SERVICES, EXTRAS_LIST, createWhatsAppBookingUrl } from '../data/studioData';

interface BookingContactSectionProps {
  selectedServiceName?: string;
}

export const BookingContactSection: React.FC<BookingContactSectionProps> = ({ selectedServiceName }) => {
  const [selectedService, setSelectedService] = useState(selectedServiceName || BOOKING_SERVICES[0].name);
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);
  const [clientName, setClientName] = useState('');
  const [dayPreference, setDayPreference] = useState('Esta semana (o quanto antes)');
  const [period, setPeriod] = useState<'manha' | 'tarde'>('tarde');
  const [notes, setNotes] = useState('');
  const [isCopied, setIsCopied] = useState(false);

  React.useEffect(() => {
    if (selectedServiceName) {
      setSelectedService(selectedServiceName);
    }
  }, [selectedServiceName]);

  const toggleExtra = (extraName: string) => {
    setSelectedExtras((prev) =>
      prev.includes(extraName) ? prev.filter((item) => item !== extraName) : [...prev, extraName]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const url = createWhatsAppBookingUrl({
      serviceName: selectedService,
      clientName: clientName.trim(),
      dayPreference,
      period,
      extras: selectedExtras,
      notes: notes.trim(),
    });
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const copyAddress = () => {
    navigator.clipboard.writeText('Rua Amazonas, N 115. Bairro Brasília - Araguari MG');
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <section id="contato" className="py-24 sm:py-32 bg-[#F3ECE7]/40 relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 sm:mb-20">
          <span className="text-xs uppercase tracking-[0.25em] font-semibold text-[#6B21A8] block mb-3">
            Atendimento com Hora Marcada
          </span>
          <h2 className="font-editorial text-fluid-section text-[#1C1226] font-normal mb-4">
            Agende seu Momento
          </h2>
          <p className="text-sm sm:text-base text-[#6B6275] font-light leading-relaxed">
            Selecione seu serviço e opcionais na tabela de valores para falar direto com a Stephany.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          
          {/* Online Booking Interactive Form (7 cols) */}
          <div className="lg:col-span-7 bg-white p-8 sm:p-10 rounded-[32px] shadow-lg border border-[#6B21A8]/10">
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-[#6B21A8]/10">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#F472B6]/20 flex items-center justify-center text-[#6B21A8]">
                  <Calendar className="w-4 h-4" />
                </div>
                <h3 className="font-editorial text-xl font-medium text-[#1C1226]">
                  Solicitação de Horário
                </h3>
              </div>
              <span className="text-xs text-[#6B6275] font-medium hidden sm:inline-block">
                Sem intermediários • Direto no WhatsApp
              </span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Service Selection Dropdown */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#1C1226] mb-2">
                  1. Procedimento Desejado (Tabela de Valores)
                </label>
                <select
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                  className="w-full px-4 py-3.5 rounded-xl border border-[#6B21A8]/20 bg-[#FAF7F5] text-sm text-[#1C1226] focus:outline-none focus:border-[#6B21A8] focus:ring-1 focus:ring-[#6B21A8] transition-colors"
                >
                  <optgroup label="Alongamento Fibra de Vidro">
                    <option value="Alongamento Fibra • Simples (R$ 130)">Alongamento Fibra • Simples — R$ 130</option>
                    <option value="Alongamento Fibra • Esmaltação (R$ 140)">Alongamento Fibra • Esmaltação — R$ 140</option>
                    <option value="Alongamento Fibra • Encapsulado (R$ 150)">Alongamento Fibra • Encapsulado — R$ 150</option>
                  </optgroup>
                  <optgroup label="Manutenção Fibra de Vidro">
                    <option value="Manutenção Fibra • Simples (R$ 90)">Manutenção Fibra • Simples — R$ 90</option>
                    <option value="Manutenção Fibra • Esmaltação (R$ 100)">Manutenção Fibra • Esmaltação — R$ 100</option>
                    <option value="Manutenção Fibra • Encapsulado (R$ 110)">Manutenção Fibra • Encapsulado — R$ 110</option>
                  </optgroup>
                  <optgroup label="Banho de Gel">
                    <option value="Banho de Gel • Simples (R$ 100)">Banho de Gel • Simples — R$ 100</option>
                    <option value="Banho de Gel • Esmaltação (R$ 110)">Banho de Gel • Esmaltação — R$ 110</option>
                    <option value="Banho de Gel • Encapsulado (R$ 120)">Banho de Gel • Encapsulado — R$ 120</option>
                  </optgroup>
                  <optgroup label="Manutenção Banho de Gel">
                    <option value="Manutenção Banho de Gel • Simples (R$ 80)">Manutenção Banho de Gel • Simples — R$ 80</option>
                    <option value="Manutenção Banho de Gel • Esmaltação (R$ 90)">Manutenção Banho de Gel • Esmaltação — R$ 90</option>
                    <option value="Manutenção Banho de Gel • Encapsulado (R$ 100)">Manutenção Banho de Gel • Encapsulado — R$ 100</option>
                  </optgroup>
                </select>
              </div>

              {/* Extras Multi-Select Checkboxes */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#1C1226] mb-2.5">
                  2. Extras / Adicionais (opcional)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {EXTRAS_LIST.map((extra) => {
                    const isChecked = selectedExtras.includes(`${extra.name} (${extra.priceFormatted})`);
                    return (
                      <button
                        type="button"
                        key={extra.id}
                        onClick={() => toggleExtra(`${extra.name} (${extra.priceFormatted})`)}
                        className={`flex items-center gap-2 p-3 rounded-xl border text-xs text-left transition-all ${
                          isChecked
                            ? 'bg-[#6B21A8]/10 border-[#6B21A8] text-[#6B21A8] font-semibold'
                            : 'bg-[#FAF7F5] border-[#6B21A8]/15 text-[#1C1226] hover:border-[#F472B6]'
                        }`}
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-[#6B21A8] shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-[#6B6275] shrink-0" />
                        )}
                        <div className="leading-tight">
                          <span>{extra.name}</span>
                          <span className="block text-[11px] text-[#6B21A8] font-bold">
                            {extra.priceFormatted}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Day & Period Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs uppercase tracking-wider font-semibold text-[#1C1226] mb-2">
                    3. Preferência de Dia
                  </label>
                  <select
                    value={dayPreference}
                    onChange={(e) => setDayPreference(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-[#6B21A8]/20 bg-[#FAF7F5] text-sm text-[#1C1226] focus:outline-none focus:border-[#6B21A8] focus:ring-1 focus:ring-[#6B21A8] transition-colors"
                  >
                    <option value="Esta semana (o quanto antes)">Esta semana (o quanto antes)</option>
                    <option value="Próxima semana">Próxima semana</option>
                    <option value="Quinta ou Sexta-feira">Quinta ou Sexta-feira</option>
                    <option value="Sábado">Sábado</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider font-semibold text-[#1C1226] mb-2">
                    4. Período do dia
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPeriod('manha')}
                      className={`py-3 px-3 rounded-xl border text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${
                        period === 'manha'
                          ? 'bg-[#6B21A8] text-white border-[#6B21A8]'
                          : 'bg-[#FAF7F5] text-[#1C1226] border-[#6B21A8]/15 hover:border-[#6B21A8]/40'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>Manhã (09h-12h)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPeriod('tarde')}
                      className={`py-3 px-3 rounded-xl border text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${
                        period === 'tarde'
                          ? 'bg-[#6B21A8] text-white border-[#6B21A8]'
                          : 'bg-[#FAF7F5] text-[#1C1226] border-[#6B21A8]/15 hover:border-[#6B21A8]/40'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>Tarde (13h-18h)</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Client Name Input */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#1C1226] mb-2">
                  5. Seu nome completo
                </label>
                <input
                  type="text"
                  required
                  placeholder="Como você gostaria de ser chamada?"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-[#6B21A8]/20 bg-[#FAF7F5] text-sm text-[#1C1226] placeholder-[#6B6275]/60 focus:outline-none focus:border-[#6B21A8] focus:ring-1 focus:ring-[#6B21A8] transition-colors"
                />
              </div>

              {/* Optional Notes */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#1C1226] mb-2">
                  6. Observações adicionais (opcional)
                </label>
                <input
                  type="text"
                  placeholder="Ex: unha com formato específico, referência de cor..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-[#6B21A8]/20 bg-[#FAF7F5] text-sm text-[#1C1226] placeholder-[#6B6275]/60 focus:outline-none focus:border-[#6B21A8] focus:ring-1 focus:ring-[#6B21A8] transition-colors"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="w-full py-4 px-6 rounded-full bg-[#6B21A8] hover:bg-[#581c87] text-white text-sm uppercase tracking-wider font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-3 transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <MessageCircle className="w-5 h-5 text-[#F472B6]" />
                <span>Entrar em contato via WhatsApp</span>
              </button>

              <p className="text-center text-[11px] text-[#6B6275]">
                Sua mensagem será gerada automaticamente com o valor e itens selecionados.
              </p>
            </form>
          </div>

          {/* Studio Contact & Location Details (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Direct Quick WhatsApp Card */}
            <div className="bg-[#6B21A8] text-white p-8 rounded-[32px] shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-44 h-44 bg-[#F472B6]/20 rounded-full blur-2xl pointer-events-none" />
              
              <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#F472B6] block mb-2">
                Atendimento Direto
              </span>
              <h3 className="font-editorial text-2xl font-normal mb-3">
                Prefere conversar agora?
              </h3>
              <p className="text-xs sm:text-sm text-white/80 font-light leading-relaxed mb-6">
                Tire dúvidas sobre a tabela de valores, envie foto das suas unhas ou combine seu horário.
              </p>

              <div className="space-y-3 mb-6">
                <a
                  href={`tel:${STUDIO_INFO.phoneClean}`}
                  className="flex items-center gap-3 p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors text-white"
                >
                  <Phone className="w-4 h-4 text-[#F472B6]" />
                  <span className="text-sm font-medium">{STUDIO_INFO.phoneDisplay}</span>
                </a>

                <a
                  href={`https://wa.me/${STUDIO_INFO.phoneClean}?text=${encodeURIComponent('Olá, Stephany! Vim pelo site e gostaria de agendar um horário com base na tabela de valores.')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 w-full py-3.5 px-4 rounded-full bg-white text-[#6B21A8] hover:bg-[#FAF7F5] text-xs uppercase tracking-wider font-semibold transition-all duration-200 shadow-md"
                >
                  <MessageCircle className="w-4 h-4 text-[#6B21A8]" />
                  <span>Chamar no WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Address & Studio Location */}
            <div className="bg-white p-8 rounded-[32px] shadow-sm border border-[#6B21A8]/10">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-10 h-10 rounded-2xl bg-[#6B21A8]/10 flex items-center justify-center text-[#6B21A8] shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-editorial text-lg font-medium text-[#1C1226]">
                    Endereço do Ateliê
                  </h4>
                  <p className="text-xs sm:text-sm text-[#6B6275] font-light mt-1">
                    {STUDIO_INFO.address}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-[#6B21A8]/10">
                <a
                  href={STUDIO_INFO.mapsQuery}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#6B21A8] hover:underline"
                >
                  <span>Abrir no Google Maps</span>
                </a>
                <span className="text-[#6B6275]/40">•</span>
                <button
                  type="button"
                  onClick={copyAddress}
                  className="text-xs text-[#6B6275] hover:text-[#1C1226] transition-colors"
                >
                  {isCopied ? 'Endereço copiado!' : 'Copiar endereço'}
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
