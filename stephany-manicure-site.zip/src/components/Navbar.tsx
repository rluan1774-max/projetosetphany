import React, { useState, useEffect } from 'react';
import { Sparkles, Calendar, Menu, X, ArrowUpRight } from 'lucide-react';
import { STUDIO_INFO } from '../data/studioData';

interface NavbarProps {
  onContactClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onContactClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Galeria', href: '#galeria' },
    { label: 'O Ateliê', href: '#sobre' },
    { label: 'Contato', href: '#contato' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAF7F5]/90 backdrop-blur-md border-b border-[#6B21A8]/10 py-3.5 shadow-xs'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex items-center justify-between">
        {/* Brand */}
        <a
          href="#inicio"
          className="group flex flex-col items-start transition-opacity hover:opacity-90"
        >
          <span className="font-editorial text-2xl sm:text-3xl tracking-widest font-bold text-[#6B21A8]">
            {STUDIO_INFO.name}
          </span>
          <span className="text-[10px] tracking-[0.28em] uppercase text-[#6B6275] -mt-1 font-medium">
            Estúdio de Manicure
          </span>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={(e) => handleLinkClick(e, link.href)}
              className="text-xs uppercase tracking-[0.16em] text-[#1C1226]/80 hover:text-[#6B21A8] font-medium transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1.5px] after:bg-[#F472B6] hover:after:w-full after:transition-all after:duration-300"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Action Button & Status */}
        <div className="hidden sm:flex items-center gap-3">
          <a
            href="/stephany-manicure-site.zip"
            download="stephany-manicure-site.zip"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-white border border-[#6B21A8]/25 hover:border-[#6B21A8] hover:bg-[#FAF7F5] text-[#6B21A8] text-xs font-semibold shadow-2xs transition-all"
            title="Baixar código-fonte em ZIP para Lovable ou Netlify"
          >
            <span>Baixar ZIP</span>
          </a>

          <button
            onClick={onContactClick}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#6B21A8] hover:bg-[#581c87] text-white text-xs uppercase tracking-wider font-semibold shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <span>Entrar em contato</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-[#F472B6]" />
          </button>
        </div>

        {/* Mobile menu trigger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Abrir menu"
          className="md:hidden p-2 text-[#6B21A8] hover:text-[#581c87] focus:outline-none"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FAF7F5] border-b border-[#6B21A8]/10 px-6 pt-4 pb-8 shadow-xl animate-in fade-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col space-y-4 pt-2 pb-6">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="text-base font-medium text-[#1C1226] hover:text-[#6B21A8] py-2 border-b border-[#6B21A8]/5"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="pt-2 flex flex-col gap-2.5">
            <a
              href="/stephany-manicure-site.zip"
              download="stephany-manicure-site.zip"
              className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-full bg-white border border-[#6B21A8]/30 text-[#6B21A8] text-sm font-semibold shadow-xs"
            >
              <span>Baixar ZIP do Projeto</span>
            </a>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onContactClick();
              }}
              className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-full bg-[#6B21A8] text-white text-sm font-semibold shadow-md active:bg-[#581c87]"
            >
              <Calendar className="w-4 h-4 text-[#F472B6]" />
              <span>Entrar em contato</span>
            </button>
            <p className="text-center text-xs text-[#6B6275] mt-2">
              Rua Amazonas, 115 • Araguari - MG
            </p>
          </div>
        </div>
      )}
    </header>
  );
};
