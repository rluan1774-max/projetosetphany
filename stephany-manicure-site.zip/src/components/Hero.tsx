import React from 'react';
import { ArrowDown, MessageCircle, Sparkles } from 'lucide-react';
import { STUDIO_INFO } from '../data/studioData';

interface HeroProps {
  onContactClick: () => void;
  onExploreClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onContactClick, onExploreClick }) => {
  return (
    <section
      id="inicio"
      className="relative min-h-[92vh] pt-28 sm:pt-36 pb-16 flex flex-col justify-between overflow-hidden"
    >
      {/* Subtle organic background gradient accents */}
      <div className="absolute top-12 right-0 w-96 h-96 bg-[#F472B6]/12 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-0 w-80 h-80 bg-[#6B21A8]/8 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 w-full flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Text Content Column */}
          <div className="lg:col-span-7 flex flex-col items-start z-10">
            {/* Tagline pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/80 border border-[#6B21A8]/15 shadow-xs mb-6 sm:mb-8 backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5 text-[#F472B6]" />
              <span className="text-xs uppercase tracking-[0.2em] font-semibold text-[#6B21A8]">
                Araguari • Minas Gerais
              </span>
            </div>

            {/* Main Headline (A arte de transformar suas unhas - 6 words) */}
            <h1 className="font-editorial text-fluid-hero text-[#1C1226] font-normal tracking-tight mb-6">
              A arte de <br />
              <span className="italic font-light text-[#6B21A8] relative inline-block">
                transformar
                <span className="absolute left-0 -bottom-1.5 w-full h-[2px] bg-gradient-to-r from-[#F472B6] to-transparent opacity-70" />
              </span>{' '}
              suas unhas.
            </h1>

            {/* Single support sentence */}
            <p className="text-base sm:text-lg text-[#6B6275] max-w-xl font-light leading-relaxed mb-8 sm:mb-10">
              Esmaltação em gel de alta durabilidade, fibra de vidro milimétrica e rituais de cuidado exclusivo para suas mãos.
            </p>

            {/* Primary Action Button & Secondary explore */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-6 w-full sm:w-auto">
              <button
                onClick={onContactClick}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-[#6B21A8] hover:bg-[#581c87] text-white text-sm uppercase tracking-wider font-semibold shadow-lg hover:shadow-xl hover:shadow-[#6B21A8]/20 transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <MessageCircle className="w-4 h-4 text-[#F472B6]" />
                <span>Entrar em contato</span>
              </button>

              <button
                onClick={onExploreClick}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-4 rounded-full bg-transparent hover:bg-white/70 border border-[#6B21A8]/20 text-[#1C1226] text-sm font-medium transition-all duration-200"
              >
                <span>Ver serviços & valores</span>
              </button>
            </div>

            {/* Micro proof info */}
            <div className="flex items-center gap-6 mt-8 sm:mt-12 pt-6 border-t border-[#6B21A8]/10 text-xs text-[#6B6275]">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#6B21A8]" />
                <span>Atendimento individualizado</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F472B6]" />
                <span>Materiais 100% esterilizados</span>
              </div>
            </div>
          </div>

          {/* Single Magnificent Manicure Photo Column */}
          <div className="lg:col-span-5 relative flex justify-center lg:justify-end">
            <div className="relative w-full max-w-md sm:max-w-lg lg:max-w-none">
              
              {/* Background decorative frame shadow */}
              <div className="absolute -inset-2 rounded-[40px] lg:arch-frame bg-gradient-to-tr from-[#6B21A8]/20 via-[#F472B6]/25 to-transparent blur-md -z-10" />

              {/* Main Photo: High aesthetic real manicured hands */}
              <div className="relative overflow-hidden rounded-[36px] lg:arch-frame border-2 border-[#FAF7F5] shadow-2xl bg-[#F3ECE7]">
                <img
                  src="https://images.unsplash.com/photo-1632345031435-8727f6897d53?auto=format&fit=crop&w=1200&q=85"
                  alt="Unhas com esmaltação e acabamento impecável no Estúdio Stephany"
                  className="w-full h-[420px] sm:h-[500px] lg:h-[560px] object-cover object-center transform hover:scale-103 transition-transform duration-700 ease-out"
                  loading="eager"
                  fetchPriority="high"
                />

                {/* Subtle vignette & light tag */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#1C1226]/40 via-transparent to-transparent pointer-events-none" />

                {/* Floating chic label on photo */}
                <div className="absolute bottom-5 left-5 right-5 p-4 rounded-2xl bg-white/90 backdrop-blur-md border border-white/60 shadow-md flex items-center justify-between">
                  <div>
                    <p className="text-[11px] uppercase tracking-wider font-semibold text-[#6B21A8]">
                      Esmaltação & Fibra
                    </p>
                    <p className="font-editorial text-sm font-medium text-[#1C1226]">
                      Acabamento fino e natural
                    </p>
                  </div>
                  <div className="h-8 w-8 rounded-full bg-[#F472B6]/20 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-[#6B21A8]" />
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Subtle invitation to scroll to the next section */}
      <div className="max-w-7xl mx-auto px-6 sm:px-8 w-full mt-6 pt-4 flex items-center justify-between border-t border-[#6B21A8]/5">
        <span className="text-[11px] uppercase tracking-[0.2em] text-[#6B6275]">
          Rua Amazonas, 115 • Bairro Brasília
        </span>
        <button
          onClick={onExploreClick}
          aria-label="Rolar para os serviços"
          className="flex items-center gap-2 text-xs font-medium text-[#6B21A8] hover:text-[#581c87] transition-colors group"
        >
          <span>Conheça os rituais</span>
          <ArrowDown className="w-3.5 h-3.5 transform group-hover:translate-y-1 transition-transform" />
        </button>
      </div>
    </section>
  );
};
