import React, { useState } from 'react';
import { Sparkles, ArrowRight, Check, PlusCircle } from 'lucide-react';
import { PRICE_CATEGORIES, EXTRAS_LIST } from '../data/studioData';
import { ServiceCategory, ServiceTier } from '../types';

interface ServicesSectionProps {
  onSelectServiceTier: (category: ServiceCategory, tier: ServiceTier) => void;
  onSelectExtra?: (extraName: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectServiceTier, onSelectExtra }) => {
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory>(PRICE_CATEGORIES[0]);

  return (
    <section id="servicos" className="py-24 sm:py-32 bg-[#F3ECE7]/50 relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-xs uppercase tracking-[0.25em] font-semibold text-[#6B21A8] block mb-3">
              Valores Transparentes
            </span>
            <h2 className="font-editorial text-fluid-section text-[#1C1226] font-normal">
              Tabela de Valores
            </h2>
          </div>
          <p className="text-sm sm:text-base text-[#6B6275] max-w-md font-light leading-relaxed">
            Alongamentos em fibra e blindagens em gel com acabamento impecável, alta fixação e materiais esterilizados.
          </p>
        </div>

        {/* Pricing Cards Grid (4 Main Categories) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10 mb-16">
          {PRICE_CATEGORIES.map((cat, idx) => {
            return (
              <div
                key={cat.id}
                className="bg-white rounded-[32px] p-7 sm:p-9 shadow-sm hover:shadow-xl transition-all duration-300 border border-[#6B21A8]/10 flex flex-col justify-between group relative overflow-hidden"
              >
                {/* Subtle top indicator for popular items */}
                {cat.popular && (
                  <div className="absolute top-0 right-8 bg-[#F472B6]/20 text-[#6B21A8] text-[10px] uppercase tracking-widest font-semibold px-4 py-1 rounded-b-xl border-x border-b border-[#F472B6]/30">
                    Mais Pedido
                  </div>
                )}

                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs font-mono font-medium text-[#6B21A8]/50">
                      0{idx + 1}
                    </span>
                    <h3 className="font-editorial text-2xl sm:text-3xl font-medium text-[#1C1226] group-hover:text-[#6B21A8] transition-colors">
                      {cat.name}
                    </h3>
                  </div>

                  <p className="text-xs sm:text-sm text-[#6B6275] font-light mb-6 leading-relaxed">
                    {cat.tagline}
                  </p>

                  {/* Tiers List (Simples, Esmaltação, Encapsulado) */}
                  <div className="space-y-3 mb-8">
                    {cat.tiers.map((tier) => (
                      <div
                        key={tier.name}
                        onClick={() => onSelectServiceTier(cat, tier)}
                        className="flex items-center justify-between p-3.5 rounded-2xl bg-[#FAF7F5] hover:bg-[#F472B6]/15 hover:border-[#F472B6]/40 border border-transparent transition-all cursor-pointer group/tier"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 rounded-full bg-[#6B21A8]" />
                          <span className="text-sm font-medium text-[#1C1226]">
                            {tier.name}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="text-lg font-editorial font-bold text-[#6B21A8]">
                            {tier.priceFormatted}
                          </span>
                          <span className="text-xs font-semibold text-[#6B21A8] opacity-0 group-hover/tier:opacity-100 transition-opacity flex items-center gap-1">
                            <span>Agendar</span>
                            <ArrowRight className="w-3 h-3" />
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Close up photo preview */}
                <div className="relative h-44 rounded-2xl overflow-hidden mt-2">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1C1226]/60 via-transparent to-transparent flex items-end p-4">
                    <span className="text-xs text-white/90 font-medium flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#F472B6]" />
                      <span>Trabalho real em unhas</span>
                    </span>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Extras & Adicionais Section */}
        <div className="bg-white rounded-[32px] p-8 sm:p-10 shadow-sm border border-[#6B21A8]/10">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-[#6B21A8]/10">
            <div>
              <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#6B21A8] block">
                Personalize seu Atendimento
              </span>
              <h3 className="font-editorial text-2xl font-normal text-[#1C1226] mt-0.5">
                Serviços Extras & Adicionais
              </h3>
            </div>
            <p className="text-xs text-[#6B6275]">
              Adicione durante o agendamento conforme sua necessidade.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {EXTRAS_LIST.map((extra) => (
              <div
                key={extra.id}
                className="p-5 rounded-2xl bg-[#FAF7F5] border border-[#6B21A8]/10 flex items-center justify-between hover:border-[#6B21A8]/30 transition-colors"
              >
                <div>
                  <h4 className="text-sm font-semibold text-[#1C1226]">
                    {extra.name}
                  </h4>
                  <span className="text-[11px] text-[#6B6275]">
                    {extra.id === 'unha-faltando' ? 'Por unidade danificada' : extra.id === 'pedraria-par' ? 'Aplicações artesanais' : 'Remoção com segurança'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-lg font-editorial font-bold text-[#6B21A8] block">
                    {extra.priceFormatted}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
