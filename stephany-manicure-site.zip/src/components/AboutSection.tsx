import React from 'react';
import { ShieldCheck, HeartHandshake, Sparkles, MapPin } from 'lucide-react';
import { STUDIO_INFO } from '../data/studioData';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-24 sm:py-32 bg-[#FAF7F5] relative overflow-hidden">
      {/* Decorative subtle background accents */}
      <div className="absolute top-1/2 -right-40 w-80 h-80 bg-[#F472B6]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Studio Image Column (5 cols) with bespoke arch mask */}
          <div className="lg:col-span-5 order-2 lg:order-1 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              <div className="overflow-hidden rounded-[36px] lg:arch-frame border-2 border-white shadow-xl bg-[#F3ECE7]">
                <img
                  src="https://images.unsplash.com/photo-1610992015732-2449b76344bc?auto=format&fit=crop&w=1000&q=80"
                  alt="Unhas com esmaltação e acabamento impecável no Estúdio Stephany"
                  className="w-full h-[440px] sm:h-[500px] object-cover object-center"
                  loading="lazy"
                />
              </div>

              {/* Float location badge */}
              <div className="absolute -bottom-6 -right-2 sm:right-6 bg-white p-4 sm:p-5 rounded-2xl shadow-lg border border-[#6B21A8]/10 max-w-[260px]">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#6B21A8]/10 flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4 text-[#6B21A8]" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-[#1C1226]">
                      Bairro Brasília
                    </p>
                    <p className="text-[11px] text-[#6B6275] leading-tight mt-0.5">
                      Rua Amazonas, 115 • Araguari, MG
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Text & Philosophy Column (7 cols) */}
          <div className="lg:col-span-7 order-1 lg:order-2 flex flex-col items-start">
            <span className="text-xs uppercase tracking-[0.25em] font-semibold text-[#6B21A8] block mb-3">
              Sobre a Stephany
            </span>

            <h2 className="font-editorial text-fluid-section text-[#1C1226] font-normal mb-6">
              O Seu Momento de Cuidado
            </h2>

            <p className="text-base sm:text-lg text-[#6B6275] font-light leading-relaxed mb-8">
              No Estúdio Stephany, manicure vai além da estética: é um ritual de autoestima e bem-estar. Cada atendimento é individual, com tempo dedicado para ouvir você e esculpir unhas que unem naturalidade, precisão e durabilidade.
            </p>

            {/* Three Pillar Points - Pure elegance, zero fluff */}
            <div className="space-y-6 w-full">
              <div className="flex items-start gap-4 p-4 rounded-2xl bg-white/60 border border-[#6B21A8]/5">
                <div className="w-10 h-10 rounded-xl bg-[#6B21A8]/10 flex items-center justify-center shrink-0 text-[#6B21A8]">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-editorial text-base font-semibold text-[#1C1226] mb-1">
                    Biossegurança Rigorosa
                  </h3>
                  <p className="text-xs sm:text-sm text-[#6B6275] font-light">
                    Instrumentais esterilizados em autoclave hospitalar e embalagens abertas exclusivamente na sua presença.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-2xl bg-white/60 border border-[#6B21A8]/5">
                <div className="w-10 h-10 rounded-xl bg-[#F472B6]/20 flex items-center justify-center shrink-0 text-[#6B21A8]">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-editorial text-base font-semibold text-[#1C1226] mb-1">
                    Preservação da Lâmina Natural
                  </h3>
                  <p className="text-xs sm:text-sm text-[#6B6275] font-light">
                    Técnicas e cosméticos hipoalergênicos que respeitam a saúde das unhas naturais sem enfraquecê-las.
                  </p>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
