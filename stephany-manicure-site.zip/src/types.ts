export interface ServiceTier {
  name: string;
  price: number;
  priceFormatted: string;
}

export interface ServiceCategory {
  id: string;
  name: string;
  tagline: string;
  image: string;
  tiers: ServiceTier[];
  popular?: boolean;
}

export interface ExtraItem {
  id: string;
  name: string;
  price: number;
  priceFormatted: string;
}

export interface ServiceItem {
  id: string;
  name: string;
  categoryName?: string;
  price: string;
  tagline?: string;
  duration?: string;
  image?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
}

export interface BookingState {
  serviceId: string;
  clientName: string;
  period: 'manha' | 'tarde';
  dayPreference: string;
  notes: string;
}
