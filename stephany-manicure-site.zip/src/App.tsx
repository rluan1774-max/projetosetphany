import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { GallerySection } from './components/GallerySection';
import { AboutSection } from './components/AboutSection';
import { BookingContactSection } from './components/BookingContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { ImageModal } from './components/ImageModal';
import { ServiceCategory, ServiceTier, GalleryItem } from './types';

export default function App() {
  const [selectedServiceName, setSelectedServiceName] = useState<string | undefined>(undefined);
  const [activeModalImage, setActiveModalImage] = useState<GalleryItem | null>(null);

  const scrollToContact = () => {
    const el = document.getElementById('contato');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToServices = () => {
    const el = document.getElementById('servicos');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectServiceTier = (category: ServiceCategory, tier: ServiceTier) => {
    let prefix = 'Alongamento Fibra';
    if (category.id === 'alongamento-fibra') prefix = 'Alongamento Fibra';
    else if (category.id === 'manutencao-fibra') prefix = 'Manutenção Fibra';
    else if (category.id === 'banho-de-gel') prefix = 'Banho de Gel';
    else if (category.id === 'manutencao-banho-gel') prefix = 'Manutenção Banho de Gel';

    setSelectedServiceName(`${prefix} • ${tier.name} (${tier.priceFormatted})`);
    scrollToContact();
  };

  return (
    <div className="min-h-screen bg-[#FAF7F5] text-[#1C1226] selection:bg-[#F472B6]/30 selection:text-[#6B21A8] relative">
      {/* Navigation */}
      <Navbar onContactClick={scrollToContact} />

      {/* Hero Section */}
      <main>
        <Hero
          onContactClick={scrollToContact}
          onExploreClick={scrollToServices}
        />

        {/* Services & Price Table Section */}
        <ServicesSection onSelectServiceTier={handleSelectServiceTier} />

        {/* Gallery Section */}
        <GallerySection onOpenImage={(item) => setActiveModalImage(item)} />

        {/* About Section */}
        <AboutSection />

        {/* Booking & Contact Section */}
        <BookingContactSection selectedServiceName={selectedServiceName} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating Action Button */}
      <FloatingWhatsApp />

      {/* Lightbox Modal */}
      <ImageModal
        item={activeModalImage}
        onClose={() => setActiveModalImage(null)}
      />
    </div>
  );
}
