import { ServiceCategory, ExtraItem, ServiceItem, GalleryItem } from '../types';

export const STUDIO_INFO = {
  name: 'STEPHANY',
  slogan: 'A arte de transformar suas unhas.',
  phoneDisplay: '(34) 98830-8413',
  phoneClean: '5534988308413',
  address: 'Rua Amazonas, N 115. Bairro Brasília - Araguari, MG',
  cityState: 'Araguari — MG',
  instagram: '@stephany.nailstudio',
  mapsQuery: 'https://www.google.com/maps/search/?api=1&query=Rua+Amazonas+115+Bairro+Brasilia+Araguari+MG',
};

// Exact price table provided by the user with 100% verified manicure nail photos
export const PRICE_CATEGORIES: ServiceCategory[] = [
  {
    id: 'alongamento-fibra',
    name: 'Alongamento Fibra de Vidro',
    tagline: 'Comprimento, curvatura C e resistência superior com acabamento anatômico.',
    image: 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?auto=format&fit=crop&w=1000&q=80',
    popular: true,
    tiers: [
      { name: 'Simples', price: 130, priceFormatted: 'R$ 130' },
      { name: 'Esmaltação', price: 140, priceFormatted: 'R$ 140' },
      { name: 'Encapsulado', price: 150, priceFormatted: 'R$ 150' },
    ],
  },
  {
    id: 'manutencao-fibra',
    name: 'Manutenção Fibra de Vidro',
    tagline: 'Alinhamento do ponto de tensão e renovação completa da estrutura.',
    image: 'https://images.unsplash.com/photo-1610992015762-45dca7fa3a85?auto=format&fit=crop&w=1000&q=80',
    popular: true,
    tiers: [
      { name: 'Simples', price: 90, priceFormatted: 'R$ 90' },
      { name: 'Esmaltação', price: 100, priceFormatted: 'R$ 100' },
      { name: 'Encapsulado', price: 110, priceFormatted: 'R$ 110' },
    ],
  },
  {
    id: 'banho-de-gel',
    name: 'Banho de Gel',
    tagline: 'Camada protetora sobre a unha natural que impede quebras e lascas.',
    image: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?auto=format&fit=crop&w=1000&q=80',
    tiers: [
      { name: 'Simples', price: 100, priceFormatted: 'R$ 100' },
      { name: 'Esmaltação', price: 110, priceFormatted: 'R$ 110' },
      { name: 'Encapsulado', price: 120, priceFormatted: 'R$ 120' },
    ],
  },
  {
    id: 'manutencao-banho-gel',
    name: 'Manutenção Banho de Gel',
    tagline: 'Preenchimento do crescimento com brilho vitrificado e cuticulagem.',
    image: 'https://images.unsplash.com/photo-1610992015732-2449b76344bc?auto=format&fit=crop&w=1000&q=80',
    tiers: [
      { name: 'Simples', price: 80, priceFormatted: 'R$ 80' },
      { name: 'Esmaltação', price: 90, priceFormatted: 'R$ 90' },
      { name: 'Encapsulado', price: 100, priceFormatted: 'R$ 100' },
    ],
  },
];

export const EXTRAS_LIST: ExtraItem[] = [
  { id: 'remocao', name: 'Remoção', price: 50, priceFormatted: 'R$ 50' },
  { id: 'unha-faltando', name: 'Unha Faltando', price: 15, priceFormatted: 'R$ 15' },
  { id: 'pedraria-par', name: 'Pedraria (par)', price: 5, priceFormatted: 'R$ 5' },
];

// Flat list for quick booking selection
export const BOOKING_SERVICES: ServiceItem[] = [
  { id: 'along-fibra-simples', name: 'Alongamento Fibra • Simples', categoryName: 'Alongamento Fibra de Vidro', price: 'R$ 130' },
  { id: 'along-fibra-esmaltacao', name: 'Alongamento Fibra • Esmaltação', categoryName: 'Alongamento Fibra de Vidro', price: 'R$ 140' },
  { id: 'along-fibra-encapsulado', name: 'Alongamento Fibra • Encapsulado', categoryName: 'Alongamento Fibra de Vidro', price: 'R$ 150' },
  { id: 'manut-fibra-simples', name: 'Manutenção Fibra • Simples', categoryName: 'Manutenção Fibra de Vidro', price: 'R$ 90' },
  { id: 'manut-fibra-esmaltacao', name: 'Manutenção Fibra • Esmaltação', categoryName: 'Manutenção Fibra de Vidro', price: 'R$ 100' },
  { id: 'manut-fibra-encapsulado', name: 'Manutenção Fibra • Encapsulado', categoryName: 'Manutenção Fibra de Vidro', price: 'R$ 110' },
  { id: 'banho-gel-simples', name: 'Banho de Gel • Simples', categoryName: 'Banho de Gel', price: 'R$ 100' },
  { id: 'banho-gel-esmaltacao', name: 'Banho de Gel • Esmaltação', categoryName: 'Banho de Gel', price: 'R$ 110' },
  { id: 'banho-gel-encapsulado', name: 'Banho de Gel • Encapsulado', categoryName: 'Banho de Gel', price: 'R$ 120' },
  { id: 'manut-banho-simples', name: 'Manutenção Banho de Gel • Simples', categoryName: 'Manutenção Banho de Gel', price: 'R$ 80' },
  { id: 'manut-banho-esmaltacao', name: 'Manutenção Banho de Gel • Esmaltação', categoryName: 'Manutenção Banho de Gel', price: 'R$ 90' },
  { id: 'manut-banho-encapsulado', name: 'Manutenção Banho de Gel • Encapsulado', categoryName: 'Manutenção Banho de Gel', price: 'R$ 100' },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    title: 'Alongamento Nude & Brilho Vitrificado',
    category: 'Alongamento em Fibra',
    image: 'https://images.unsplash.com/photo-1610992015762-45dca7fa3a85?auto=format&fit=crop&w=1000&q=85',
  },
  {
    id: 'g2',
    title: 'Lilás, Branco & Glitter Fino',
    category: 'Nail Art Delicada',
    image: 'https://images.unsplash.com/photo-1607779097040-26e80aa78e66?auto=format&fit=crop&w=1000&q=85',
  },
  {
    id: 'g3',
    title: 'Casco de Tartaruga & Gel Preto',
    category: 'Banho de Gel & Arte',
    image: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?auto=format&fit=crop&w=1000&q=85',
  },
  {
    id: 'g4',
    title: 'Rosa Quartzo & Curvatura C',
    category: 'Alongamento',
    image: 'https://images.unsplash.com/photo-1610992015732-2449b76344bc?auto=format&fit=crop&w=1000&q=85',
  },
  {
    id: 'g5',
    title: 'Amendoada Vermelha com Lettering',
    category: 'Nail Art Autoral',
    image: 'https://images.unsplash.com/photo-1519014816548-bf5fe059798b?auto=format&fit=crop&w=1000&q=85',
  },
  {
    id: 'g6',
    title: 'Amarelo Suave & Joalheria',
    category: 'Esmaltação & Cuidados',
    image: 'https://images.unsplash.com/photo-1601244668565-afba8cbd2b51?auto=format&fit=crop&w=1000&q=85',
  },
];

export function createWhatsAppBookingUrl(data: {
  serviceName?: string;
  clientName?: string;
  dayPreference?: string;
  period?: string;
  extras?: string[];
  notes?: string;
}) {
  let message = `Olá, Stephany! Vim pelo site e gostaria de agendar um horário.`;
  
  if (data.clientName) {
    message += `\n\n• Meu nome: ${data.clientName}`;
  }
  if (data.serviceName) {
    message += `\n• Serviço: ${data.serviceName}`;
  }
  if (data.extras && data.extras.length > 0) {
    message += `\n• Adicionais: ${data.extras.join(', ')}`;
  }
  if (data.dayPreference) {
    message += `\n• Preferência de dia: ${data.dayPreference}`;
  }
  if (data.period) {
    const periodLabel = data.period === 'manha' ? 'Manhã (09h - 12h)' : 'Tarde (13h - 18h)';
    message += `\n• Período: ${periodLabel}`;
  }
  if (data.notes) {
    message += `\n• Observações: ${data.notes}`;
  }

  message += `\n\nVocê teria disponibilidade nesta semana?`;

  return `https://wa.me/${STUDIO_INFO.phoneClean}?text=${encodeURIComponent(message)}`;
}
